<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\testModel;
use Faker\Generator as Faker;

$factory->define(testModel::class, function (Faker $faker) {
    return [
        //
    ];
});
