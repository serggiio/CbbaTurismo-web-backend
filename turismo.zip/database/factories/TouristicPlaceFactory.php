<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\TouristicPlace;
use Faker\Generator as Faker;

$factory->define(TouristicPlace::class, function (Faker $faker) {
    return [
        //
    ];
});
