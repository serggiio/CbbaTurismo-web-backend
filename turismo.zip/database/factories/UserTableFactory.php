<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\UserTable;
use Faker\Generator as Faker;

$factory->define(UserTable::class, function (Faker $faker) {
    return [
        //
    ];
});
